﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_pusty1.Models;

namespace mvc_pusty1.Controllers
{
    public class SklepController : Controller
    {
        SklepMuzycznyEntities sklepDB = new SklepMuzycznyEntities();
        //
        // GET: /Sklep/

        public ActionResult Index()
        {
            var gatunki = sklepDB.GatunkiMuzyczne.ToList();
            return View(gatunki);
        }
        //
        // GET: /Sklep/Browse?gatunek=string
        // GET: /Sklep/Browse?Gatunek=Disco
        public ActionResult Browse(string gatunek)
        {
            var gatunekModel = sklepDB.GatunkiMuzyczne.Include("Albumy").Single(g => g.Nazwa == gatunek);
            return View(gatunekModel);
        }

        //
        // GET: /Sklep/Details
        // GET: /Sklep/Details/3
        public ActionResult Details(int id)
        {
            var album = sklepDB.Albumy.Find(id);
            return View(album);
        }

    }
}
