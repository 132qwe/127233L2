﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_pusty1.Models;

namespace mvc_pusty1.Controllers
{
    //[Authorize(Roles = "administrator")]
    public class SklepManagerController : Controller
    {
        private SklepMuzycznyEntities db = new SklepMuzycznyEntities();

        //
        // GET: /SklepManager/
        public ViewResult Index()
        {
            var albumy = db.Albumy.Include(a => a.GatunekAlbumu).Include(a => a.NazwaArtysty);
            return View(albumy.ToList());
        }
       
        //
        // GET: /SklepManager/Details/5
        public ViewResult Details(int id)
        {
            Album album = db.Albumy.Find(id);
            return View(album);
        }

        //
        // GET: /SklepManager/Dodaj
        public ActionResult Dodaj()
        {
            ViewBag.IdGatunku = new SelectList(db.GatunkiMuzyczne, "IdGatunku", "Nazwa");
            ViewBag.IdArtysty = new SelectList(db.Artysci, "IdArtysty", "NazwaArtysty");
            return View();
        }
       
        //
        // POST: /SklepManager/Dodaj
        [HttpPost]
        public ActionResult Dodaj(Album album)
        {
            if (ModelState.IsValid)
            {
                db.Albumy.Add(album);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.IdGatunku = new SelectList(db.GatunkiMuzyczne, "IdGatunku", "Nazwa", album.IdGatunku);
            ViewBag.IdArtysty = new SelectList(db.Artysci, "IdArtysty", "NazwaArtysty", album.IdArtysty);
            return View(album);
        }
     
        //
        // GET: /SklepManager/Edit/5
        public ActionResult Edytuj(int id)
        {
            Album album = db.Albumy.Find(id);
            ViewBag.IdGatunku = new SelectList(db.GatunkiMuzyczne, "IdGatunku", "Nazwa", album.IdGatunku);
            ViewBag.IdArtysty = new SelectList(db.Artysci, "IdArtysty", "NazwaArtysty", album.IdArtysty);
            return View(album);
        }

        //
        // POST: /SklepManager/Edit/5
        [HttpPost]
        public ActionResult Edytuj(Album album)
        {
            if (ModelState.IsValid)
            {
                db.Entry(album).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.IdGatunku = new SelectList(db.GatunkiMuzyczne, "IdGatunku", "Nazwa", album.IdGatunku);
            ViewBag.IdArtysty = new SelectList(db.Artysci, "IdArtysty", "NazwaArtysty", album.IdArtysty);
            return View(album);
        }

        //
        // GET: /StoreManager/Delete/5
        public ActionResult Usun(int id)
        {
            Album album = db.Albumy.Find(id);
            return View(album);
        }

        //
        // POST: /StoreManager/Delete/5
        [HttpPost, ActionName("Usun")]
        public ActionResult DeleteConfirmed(int id)
        {
            Album album = db.Albumy.Find(id);
            db.Albumy.Remove(album);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
