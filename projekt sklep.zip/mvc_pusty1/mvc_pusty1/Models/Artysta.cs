﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations; // nie ma w tutorialu!!!!! do oznaczenia [key]

namespace mvc_pusty1.Models
{
    public class Artysta
    {
        [Key]
        public int IdArtysty { get; set; }
        public string NazwaArtysty { get; set; }
    }
}