﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace mvc_pusty1.Models
{
    public class Zamowienie
    {
        [Key]
        public int IdZamowienia { get; set; }
        public string NazwaUzytkownika { get; set; }

        public List<ZamowienieInformacje> ZamowienieInformacje { get; set; }
    }
}