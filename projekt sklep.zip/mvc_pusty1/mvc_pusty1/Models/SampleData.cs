﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace mvc_pusty1.Models
{
    public class SampleData : DropCreateDatabaseIfModelChanges<SklepMuzycznyEntities>
    {
        protected override void Seed(SklepMuzycznyEntities context)
        {
            var Gatunki = new List<Gatunek>
            {
                new Gatunek { Nazwa = "Rock" },
                new Gatunek { Nazwa = "Jazz" },
                new Gatunek { Nazwa = "Klasyczny" }
            };

            var artysci = new List<Artysta>
            {
                new Artysta{ NazwaArtysty = "Aaron Copland & London Symphony Orchestra" },
                new Artysta{ NazwaArtysty = "Aaron Goldberg" },
                new Artysta{ NazwaArtysty = "AC/DC" },
                new Artysta{ NazwaArtysty = "Accept" },
                new Artysta{ NazwaArtysty = "KISS" }
            };

            new List<Album>
            {
                new Album { TytulAlbumu = "A Copland Celebration, Vol. I", GatunekAlbumu = Gatunki.Single(g => g.Nazwa == "Klasyczny"), CenaAlbumu = 8.99M, NazwaArtysty = artysci.Single(a => a.NazwaArtysty == "Aaron Copland & London Symphony Orchestra"), AdresObrazkaArtysty = "/Content/Images/placeholder.gif" },
                new Album { TytulAlbumu = "Worlds", GatunekAlbumu = Gatunki.Single(g => g.Nazwa == "Jazz"), CenaAlbumu = 8.99M, NazwaArtysty = artysci.Single(a => a.NazwaArtysty == "Aaron Goldberg"), AdresObrazkaArtysty = "/Content/Images/placeholder.gif" },
                new Album { TytulAlbumu = "For Those About To Rock We Salute You", GatunekAlbumu = Gatunki.Single(g => g.Nazwa == "Rock"), CenaAlbumu = 8.99M, NazwaArtysty = artysci.Single(a => a.NazwaArtysty == "AC/DC"), AdresObrazkaArtysty = "/Content/Images/placeholder.gif" },
                new Album { TytulAlbumu = "Let There Be Rock", GatunekAlbumu = Gatunki.Single(g => g.Nazwa == "Rock"), CenaAlbumu = 8.99M, NazwaArtysty = artysci.Single(a => a.NazwaArtysty == "AC/DC"), AdresObrazkaArtysty = "/Content/Images/placeholder.gif" },
                new Album { TytulAlbumu = "Balls to the Wall", GatunekAlbumu = Gatunki.Single(g => g.Nazwa == "Rock"), CenaAlbumu = 8.99M, NazwaArtysty = artysci.Single(a => a.NazwaArtysty == "Accept"), AdresObrazkaArtysty = "/Content/Images/placeholder.gif" }
            }.ForEach(a => context.Albumy.Add(a));
        }
    }
}