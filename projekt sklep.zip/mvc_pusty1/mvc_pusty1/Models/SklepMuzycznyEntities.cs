﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace mvc_pusty1.Models
{
    public class SklepMuzycznyEntities : DbContext
    {
        public DbSet<Artysta> Artysci { get; set; }
        public DbSet<Album> Albumy { get; set; }
        public DbSet<Gatunek> GatunkiMuzyczne { get; set; }
        //public DbSet<Koszyk> Koszyki { get; set; }
        //public DbSet<Zamowienie> Zamowienia { get; set; }
       // public DbSet<ZamowienieInformacje> ZamowiniaInformacje { get; set; }
    }
}