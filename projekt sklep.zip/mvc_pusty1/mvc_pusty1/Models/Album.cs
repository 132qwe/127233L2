﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations; // nie ma w tutorialu!!!!! do oznaczenia [key]
using System.Data.Entity;

namespace mvc_pusty1.Models
{
    [Bind(Exclude = "IdAlbumu")]
    public class Album
    {
        [ScaffoldColumn(false)]
        [Key]
        public int IdAlbumu { get; set; }

        [DisplayName("Gatunek")]
        public int IdGatunku { get; set; }

        [DisplayName("Artysta")]
        public int IdArtysty { get; set; }

        [Required(ErrorMessage = "Nazwa jest wymagana")]
        public string TytulAlbumu { get; set; }

        [Required(ErrorMessage = "Cena jest wymagana")]
        [Range(0.01, 100.00,
        ErrorMessage = "Cena musi być z przedziału od 0.01 do 100")]
        public decimal CenaAlbumu { get; set; }

        [DisplayName("Adres URL obrazka")]
        [StringLength(1024)]
        public string AdresObrazkaArtysty { get; set; }

        public Gatunek GatunekAlbumu { get; set; }
        public Artysta NazwaArtysty { get; set; }
    }
}