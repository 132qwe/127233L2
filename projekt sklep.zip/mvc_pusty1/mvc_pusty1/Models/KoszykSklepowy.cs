﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc_pusty1.Models
{
    public partial class KoszykSklepowy
    {
        SklepMuzycznyEntities db = new SklepMuzycznyEntities();
        string KoszykZakupowId { get; set; }
        public const string KluszSesyjnyKoszyka = "IdKoszyka";

        public static KoszykSklepowy WezKoszyk(HttpContextBase context)
        {
            var koszyk = new KoszykSklepowy();
            //1koszyk.KoszykZakupowId = koszyk.db(context);
            return koszyk;
        }
    }
}