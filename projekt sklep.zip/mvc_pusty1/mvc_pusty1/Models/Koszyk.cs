﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace mvc_pusty1.Models
{
    public class Koszyk
    {
        [Key]
        public int IdRekordu { get; set; }
        public string IdKoszyka { get; set; }
        public int IdAlbumu { get; set; }
        public int Konto { get; set; }
        public System.DateTime DataZamowienia { get; set; }
        public virtual Album Album { get; set; }
    }
}