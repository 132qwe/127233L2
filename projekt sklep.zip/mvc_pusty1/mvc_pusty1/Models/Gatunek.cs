﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;    // nie ma w tutorialu!!!!! do oznaczenia [key]

namespace mvc_pusty1.Models
{
    public class Gatunek
    {
        [Key]   // oznacza primary key
        public int IdGatunku { get; set; }
        public string Nazwa { get; set; }
        public string OpisGatunku { get; set; }
        public List<Album> Albumy { get; set; }
    }
}