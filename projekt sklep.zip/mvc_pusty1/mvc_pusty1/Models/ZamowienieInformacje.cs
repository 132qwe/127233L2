﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace mvc_pusty1.Models
{
    public class ZamowienieInformacje
    {
        [Key]
        public int IdZamowienieInformacje { get; set; }
        public int IdZamowienia { get; set; }

        public virtual Album Album { get; set; }
        public virtual Zamowienie Zamowienie { get; set; }
    }
}